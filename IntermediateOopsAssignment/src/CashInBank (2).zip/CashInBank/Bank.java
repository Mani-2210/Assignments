package CashInBank;

public class Bank {
 public int totCash() {
	return 0;
 }
}
