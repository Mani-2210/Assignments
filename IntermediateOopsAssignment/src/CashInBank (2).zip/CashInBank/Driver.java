package CashInBank;

public class Driver {
public static void main(String[] args) {
	Current c=new Current();
	Savings s=new Savings();
	int a=c.totCash();
	int b=s.totCash();
	System.out.println("total cash "+(a+b));
}
}
