package CashInBank;

public class Current extends Bank {
 public int totCash() { 
	 int cash=50000;
	 int credit=15000;
	 return cash+credit;
 }
}
