package CashInBank;

public class Savings extends Bank {
public int totCash() {
	int fd=200000;
	int saving=20000;
	return fd+saving;
}
}
