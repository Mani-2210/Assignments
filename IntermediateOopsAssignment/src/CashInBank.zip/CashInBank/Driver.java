package CashInBank;

public class Driver {
public static void main(String[] args) {
	Current c=new Current();
	Savings s=new Savings();
	int a=c.totCash(20000, 15000);
	int b=s.totCash(200000, 50000);
	System.out.println("total cash "+(a+b));
}
}
