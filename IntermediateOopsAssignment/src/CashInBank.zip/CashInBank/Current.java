package CashInBank;

public class Current extends Bank {
 public int totCash(int cash,int credit) {
	 return cash+credit;
 }
}
