package CashInBank;

public class Bank {
 public void totCash() {
	System.out.println();
 }
}
