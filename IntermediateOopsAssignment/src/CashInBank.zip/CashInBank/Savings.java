package CashInBank;

public class Savings extends Bank {
public int totCash(int fd,int saving) {
	return fd+saving;
}
}
